package tr.demoproject.controller;

import java.text.MessageFormat;
import java.util.List;

import tr.demoproject.persistent.History;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import tr.demoproject.persistent.Robot;
import tr.demoproject.persistent.Firmware;

import tr.demoproject.repository.DemoprojectRepository;

/**
 * The only and single purpose controller of this demo project.
 *
 */
@RestController
public class DemoprojectController {
	
	private DemoprojectRepository mainRepository;
	
	// Never mind the MainRepository not being constructed explicitly.
	// Spring will automatically create this bean and inject it into the constructor here.
	public DemoprojectController(DemoprojectRepository mainRepository) {
		this.mainRepository = mainRepository;
	}
	
	/**
	 * Returns a list of all robots currently stored in the database.
	 * @return List of all robots.
	 * curl admin:adminpass http://localhost:8080/robots/all
	 */
	@GetMapping(path="/robots/all", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Robot> getAllRobots() {
		return mainRepository.findAllRobots();
	}

	/**
	 * Returns a list of all firmwares currently stored in the database.
	 * @return List of all firmwares.
	 * curl -u admin:adminpass http://localhost:8080/robots/allFirmwares
	 */
	@GetMapping(path="/robots/allFirmwares", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Firmware> getAllFirmwares() {
		return mainRepository.findAllFirmwares();
	}

	/**
	 * Upload a new firmware to database in order to given inputs.
	 * @return boolean
	 * curl -X POST -u admin:adminpass --header "Content-Type: application/json" -d "{\"name\" : \"firmwareadded\", \"data\" : \"amodel\", \"date_released\" : \"2020-12-20T00:00:00.00\"}" http://localhost:8080/robots/uploadnewfirmware
	 */
	@PostMapping(path="/robots/uploadnewfirmware",produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public boolean uploadNewFirmware(@RequestBody Firmware firmware)
	{  return mainRepository.uploadNewFirmware(firmware); }

	/**
	 * Delete firmware that have given input name from database.
	 * curl -X DELETE -u admin:adminpass --header "Content-Type: application/json" http://localhost:8080/robots/deleteFirmware?name="firmware_stock_A"
	 */
	@DeleteMapping(path="/robots/deleteFirmware",produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteFirmware(@RequestParam("name")String name)
	{
		mainRepository.deleteFirmware(name);
	}

	/**
	 * Update columns of firmware with the input.
	 * curl -X POST -u admin:adminpass --header "Content-Type:application/json" "http://localhost:8080/robots/updatefirmware?firmwareName=update_firmware_stock_2&newFirmwareName=newupdate_firmware_stock_2&data=dhvvjrv54rfvneveuvehe"
	 */
	@PostMapping(path="/robots/updatefirmware",produces= MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public void updateFirmware(
			@RequestParam("firmwareName")String firmwareName,
			@RequestParam("newFirmwareName")String newFirmwareName,
			@RequestParam("data")String data)
	{   mainRepository.updateFirmware(firmwareName,newFirmwareName,data); }

	/**
	 * Update columns of firmware with the input.
	 * curl -X POST -u admin:adminpass --header "Content-Type: application/json" -d "[{\"name\": \"robot_3\", \"hardwareVersion\": \"hardware-model-abc\", \"firmwareName\": \"firmware_stock_A\"},{\"name\": \"robot_4\",\"hardwareVersion\": \"hardware-model-def\", \"firmwareName\": \"firmware_stock_A\"}]" "http://localhost:8080/robots/associateRobotsWithFirmware?firmwareName=firmware_upgrade_A_1"
	 */
	@PostMapping(path="/robots/associateRobotsWithFirmware",produces = MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public void associateRobotsWithFirmware(
			@RequestBody List<Robot> robotList,
			@RequestParam("firmwareName") String firmwareName)
	{ mainRepository.associateRobotsWithFirmware(robotList,firmwareName); }
	/**
	 * List of history of Robots and Firmwares association.
	 * @return List of History.
	 * Call it with curl -X GET -u admin:adminpass http://localhost:8080/robots/listAssociationRobotsAndFirmwares?robotName=robot_1
	 */
	@GetMapping(path="/robots/listAssociationRobotsAndFirmwares",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<History> listAssociationRobotsAndFirmwares(
			@RequestParam("robotName")String robotName)
	{return mainRepository.listAssociationRobotsAndFirmwares(robotName); }

    /**
     * Download the latest firmware to the Robots
     * @param robotName to be updated
     * @return boolean
     * Call it with curl -X GET -u user:password http://localhost:8080/user/downloadTheLatestFirmware?robotName=robot_1
     */
    @GetMapping(path="/user/downloadTheLatestFirmware",produces=MediaType.APPLICATION_JSON_VALUE)
    public boolean downloadTheLatestFirmware(
            @RequestParam("robotName")String robotName)
    {return mainRepository.downloadTheLatestFirmware(robotName); }

    /**
	 * Just a demo call to see the possibilities of Spring controllers.
	 * Call it with e.g. http://localhost:8080/robots/democall/1?key1=hello&key2=world
	 * @param id A numeric ID
	 * @param key1 The string value of the request parameter "key1".
	 * @param key2 The string value of the request parameter "key2"
	 * @return A short text about the beauty of Spring development incorporating the given parameters.
	 */
	@GetMapping(path="/demo/{id}", produces=MediaType.TEXT_PLAIN_VALUE)
	public String demoGet(
			@PathVariable("id") Long id,
			@RequestParam("key1") String key1,
			@RequestParam("key2") String key2
			) {
		
		String text = "This is a sample call, just to show you how easy it is in Spring to "
					+ "incorporate path variables and request parameters of arbitrary types\n\n"
					+ "The given parameters are: \n"
					+ " * id: {0}\n"
					+ " * key1: {1}\n"
					+ " * key2: {2}\n";
						
		return MessageFormat.format(text, id, key1, key2);
	}
	
	/**
	 * Super simple demo call that shows how easy it is with Spring to post a Java object and also to return one.
	 * This call simple returns the robot object it has been given.
	 * Spring will automatically take care about JSON to Java (de-)serialization.
	 * 
	 * This is an example of how this controller can be called with curl from the command line:
	 * curl -X POST --header "Content-Type: application/json" -d '{"name" : "robot number 11", "hardware_version" : "a completly new model"}' http://localhost:8080/demo
	 * 
	 * 
	 * @param robot The robot object received via the POST call
	 * @return The same robot as received via the POST body.
	 */
	@PostMapping(path="/demo", produces=MediaType.APPLICATION_JSON_VALUE, consumes=MediaType.APPLICATION_JSON_VALUE)
	public Robot demoPost(@RequestBody Robot robot) {
		return robot;
	}
}

