package tr.demoproject.persistent;
import java.sql.Timestamp;

public class History {

    public static final String TABLE_NAME = "History";
    public static final String ID = "id";
    public static final String ROBOT_NAME = "robot_name";
    public static final String FIRMWARE_NAME = "firmware_name";
    public static final String DATE_ASSOCIATED= "date_associated";

    private Integer id;

    private String robot_name;

    private String firmware_name;

    private Timestamp date_associated;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRobot_name() {
        return robot_name;
    }

    public void setRobot_name(String robot_name) {
        this.robot_name = robot_name;
    }

    public String getFirmware_name() {
        return firmware_name;
    }

    public void setFirmware_name(String firmware_name) {
        this.firmware_name = firmware_name;
    }

    public Timestamp getDate_associated() {
        return date_associated;
    }

    public void setDate_associated(Timestamp date_associated) {
        this.date_associated = date_associated;
    }


    @Override
    public String toString() {
        return "History [robot_name=" + robot_name + ", firmware_name=" + firmware_name + ", date_associated= " + date_associated + "]";
    }



}
