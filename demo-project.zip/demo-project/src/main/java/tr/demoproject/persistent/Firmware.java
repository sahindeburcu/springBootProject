package tr.demoproject.persistent;
import java.sql.Timestamp;

/**
 * Domain object for a firmware.
 *
 */
public class Firmware {

	public static final String TABLE_NAME = "Firmwares";
	public static final String NAME = "name";
	public static final String DATA = "data";
	public static final String DATE_RELEASED = "date_released";

	private String name;
	
	private String data;

	private Timestamp date_released;

	public Timestamp getDate_released() {
		return date_released;
	}

	public void setDate_released(Timestamp date_released) {
		this.date_released = date_released;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Firmware other = (Firmware) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Firmware [name=" + name + ", data=" + data +" , date_released="+ date_released+" ]";
	}


}
