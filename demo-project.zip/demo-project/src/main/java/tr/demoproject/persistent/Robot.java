package tr.demoproject.persistent;

/**
 * Domain object for a robot.
 *
 */
public class Robot {

	public static final String TABLE_NAME = "Robots";
	public static final String NAME = "name";
	public static final String HARDWARE_VERSION = "hardware_version";
	public static final String FIRMWARE_NAME = "firmware_name";
	
	private String name;
	
	private String hardwareVersion;

	private String firmwareName;

	public String getFirmwareName() {
		return firmwareName;
	}

	public void setFirmwareName(String firmwareName) {
		this.firmwareName = firmwareName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHardwareVersion() {
		return hardwareVersion;
	}

	public void setHardwareVersion(String hardwareVersion) {
		this.hardwareVersion = hardwareVersion;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Robot other = (Robot) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Robot [name=" + name + ", hardwareVersion=" + hardwareVersion + ", firmwareName= " + firmwareName + "]";
	}

}
