package tr.demoproject.repository;

import tr.demoproject.repository.exceptions.InvalidRequestException;
import tr.demoproject.persistent.History;
import tr.demoproject.persistent.Firmware;
import tr.demoproject.persistent.Robot;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The main and single repository for the demo project.
 * It handles all the SQL queries as it interacts with the database.
 */

@Repository
public class DemoprojectRepository {

    private JdbcTemplate jdbcTemplate;

    // Nevermind the constructor not being called eplicitely somewhere in the code
    // Spring does this implicitly via its dependency injection mechanism
    // It also makes sure that the DataSource parameter gets constructor and that
    // it is injected properly here.
    public DemoprojectRepository(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    /**
     * Get a list of all the robots that are currently stored in the database.
     *
     * @return A list of {@link Robot} objects.
     */
    public List<Robot> findAllRobots() {
        return jdbcTemplate.query("SELECT * FROM Robots", RobotMapper.getInstance());
    }

    /**
     * Get a list of all the firmwares that are currently stored in the database.
     * @return A list of Firmware object.
     */

    public List<Firmware> findAllFirmwares() {
        return jdbcTemplate.query("SELECT * " +
                " FROM " + Firmware.TABLE_NAME, FirmwareMapper.getInstance());
    }

    /**
     * Create new firmware object on database.
     * @param firmware object
     * @return If the process succeeded return true, else return false
     * @throws InvalidRequestException when fields doesnt fit the conditions
     */

    public boolean uploadNewFirmware(Firmware firmware) throws InvalidRequestException {
        if (firmware == null || StringUtils.isEmpty(firmware.getName()) || StringUtils.isEmpty(firmware.getData())) {
            throw new InvalidRequestException("The information of Firmware that upload must be filled");
        }
        if (!firmware.getName().matches("[_a-zA-Z0-9_ ]+")) {
            throw new InvalidRequestException("The name is invalid");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        String formattedDate = sdf.format(firmware.getDate_released());

        int inserted = jdbcTemplate.
                update("INSERT INTO " + Firmware.TABLE_NAME +
                                            " (" +
                                            Firmware.NAME + ", " +
                                            Firmware.DATA + ", " +
                                            Firmware.DATE_RELEASED +
                                            ") VALUES (?,?,?)", firmware.getName(), firmware.getData(),formattedDate );
        return inserted > 0;
    }

    /**
     * Delete firmware from database which has given name.
     * @param name of firmware
     * @return true if the record deleted.
     */
    public boolean deleteFirmware(String name) throws InvalidRequestException{
        if (StringUtils.isEmpty(name)) {
            throw new InvalidRequestException("Firmware name of the record to be deleted has to be filled");
        }

        if (!name.matches("[_a-zA-Z0-9_ ]+")) {
            throw new InvalidRequestException("the name is invalid");
        }

        int row = jdbcTemplate.update("DELETE FROM " + Firmware.TABLE_NAME
                                              + " WHERE " + Firmware.NAME + " = ?", name);
        return row>0;
    }

    /**
     * Update FirmwareName or/and Data fields of Firmware.
     * @param firmwareName
     * @param newFirmwareName
     * @param data
     * @return true if the update succeeded.
     * @throws InvalidRequestException when fields doesnt fit the conditions
     * */

    public boolean updateFirmware(String firmwareName, String newFirmwareName, String data) throws InvalidRequestException{
        if (StringUtils.isEmpty(newFirmwareName) && StringUtils.isEmpty(data)) {
            throw new InvalidRequestException("At least one of the fields to be updated must be filled");
        }

        if (StringUtils.isEmpty(firmwareName)) {
            throw new InvalidRequestException("Firmware name of the record to be updated has to be filled");
        }

        if (!firmwareName.matches("[a-zA-Z0-9_ ]+")) {
            throw new InvalidRequestException("The firmware name is invalid");
        }

        String updateSql = "UPDATE " + Firmware.TABLE_NAME + " SET ";
        boolean data_flag = false;
        boolean name_flag = false;
        if (!StringUtils.isEmpty(data)) {
            updateSql += Firmware.DATA + " = ? ";
            data_flag = true;
        }
        if (!StringUtils.isEmpty(newFirmwareName)) {
            if (!newFirmwareName.matches("[a-zA-Z0-9_ ]+")) {
                throw new InvalidRequestException("The name is invalid");
            }
            if (data_flag) {
                updateSql += " , ";
            }
            updateSql += Firmware.NAME + " = ?  ";
            name_flag = true;
        }
        updateSql += " WHERE " + Firmware.NAME + " = ? ";

        if (name_flag && data_flag)
            return jdbcTemplate.update(updateSql, data, newFirmwareName, firmwareName) > 0;
        else if (data_flag)
            return jdbcTemplate.update(updateSql, data, firmwareName) > 0;

        return jdbcTemplate.update(updateSql, newFirmwareName, firmwareName) > 0;
    }

    /**
     * The method works for association with Robot and Firmware.Call from associateRobotsWithFirmware method.
     * @param robotName
     * @param firmwareName
     * @return true if the update succeeded.
     * @throws InvalidRequestException when fields doesn't fit the conditions.
     * */

    public boolean updateRobotFirmware(String robotName, String firmwareName) throws InvalidRequestException {
        try {
            findFirmwareAndValidate(firmwareName);
            findRobotAndValidate(robotName);

            if (firmwareName.matches("[a-zA-Z0-9_ ]")) {
                throw new InvalidRequestException("The firmware name is invalid");
            }
            int updated_row = jdbcTemplate.
                    update("UPDATE " + Robot.TABLE_NAME
                                + " SET " + Robot.FIRMWARE_NAME + " = ?  "
                              + " WHERE " + Robot.NAME + " = ? ", firmwareName, robotName);

            boolean insert_result = addRelationtToHistory(robotName, firmwareName);

            return updated_row > 0 && insert_result;
        } catch (DataAccessException e) {
            return false;
        }
    }

    /**
     * The method get associated Robots with one Firmware.
     * @param robotList The List consist of Robot objects.
     * @param firmwareName to be associated with Robots.
     * @return List of mapping boolean variables.
     * @throws InvalidRequestException when fields doesn't fit the conditions.
     */
    public List<Boolean> associateRobotsWithFirmware(List<Robot> robotList, String firmwareName) throws InvalidRequestException {
        return robotList.stream().map(robot -> {
                    if (!firmwareName.equals(robot.getFirmwareName())) {
                        String t = robot.getName();
                        boolean update_result = updateRobotFirmware(robot.getName(), firmwareName);
                        return update_result;
                    }
                    return true;
                }
        ).collect(Collectors.toList());

    }

    /**
     * Find given robot from database.
     * @param robotName
     * @return Robot object
     * @throws InvalidRequestException
     */
    public Robot findRobotAndValidate(String robotName) throws InvalidRequestException {
        if (StringUtils.isEmpty(robotName)) {
            throw new InvalidRequestException("Robot name should be valid");
        }

        Robot robot = jdbcTemplate.queryForObject
                 ( "SELECT * " +
                        " FROM " + Robot.TABLE_NAME
                     + " WHERE " + Robot.NAME + " = ? ", RobotMapper.getInstance(), robotName);

        return robot;
    }

    /**
     * Find given firmware from database
     * @param name
     * @return Firmware object
     */
    public Firmware findFirmwareAndValidate(String name) throws  InvalidRequestException{
        if (StringUtils.isEmpty(name)) {
            throw new InvalidRequestException("Invalid firmware name");
        }
        Firmware firmware = jdbcTemplate.queryForObject
                    ("SELECT * " +
                         "  FROM " + Firmware.TABLE_NAME
                        + " WHERE " + Firmware.NAME + " = ? ", FirmwareMapper.getInstance(), name);

        return firmware;
    }

    /**
     * When the association occures this method record the association in History table.This method calling from updateRobotFirmware.
     * @param robotName
     * @param FirmwareName
     * @return true when operation succedeed.
     */
    public boolean addRelationtToHistory(String robotName, String FirmwareName) {
        int insert_result = jdbcTemplate.update("INSERT INTO " + History.TABLE_NAME +
                        " (" +
                        History.ROBOT_NAME + "," +
                        History.FIRMWARE_NAME + ", " +
                        History.DATE_ASSOCIATED +
                        ") VALUES (?,?,?)", robotName, FirmwareName, LocalDate.now());

        return insert_result > 0;
    }

    /**
     * get List of all History records that given robot.
     * @param robotName
     * @return List of History information
     */
    public List<History> listAssociationRobotsAndFirmwares(String robotName) throws InvalidRequestException{
        if (StringUtils.isEmpty(robotName)) {
            throw new InvalidRequestException("At least one of the fields must be filled");
        }
        return jdbcTemplate.query("SELECT * " +
                                        " FROM " + History.TABLE_NAME +
                                       " WHERE " + History.ROBOT_NAME + " = ? ", HistoryMapper.getInstance(), robotName);
    }

    /**
     * Download latest firmwares to given robots
     * @param robotName that will be updated
     * @return true
     */
    public boolean downloadTheLatestFirmware(String robotName) throws InvalidRequestException{
        try {
              if (StringUtils.isEmpty(robotName)) {
                  throw new InvalidRequestException("At least one of the fields must be filled");
              }
              Firmware firmware = jdbcTemplate.queryForObject
                      ("SELECT * " +
                              " FROM " + Firmware.TABLE_NAME +
                              " WHERE " + Firmware.DATE_RELEASED + " IN " +
                              "( SELECT MAX( " + Firmware.DATE_RELEASED + ") " +
                              "FROM " + Firmware.TABLE_NAME + ")", FirmwareMapper.getInstance());

              return jdbcTemplate.update("UPDATE " + Robot.TABLE_NAME
                                             + " SET " + Robot.FIRMWARE_NAME + " = ?  "
                                           + " WHERE " + Robot.NAME + " = ? ", firmware.getName(), robotName) > 0;
        }catch (DataAccessException e){
              return false;
        }
    }
}

class FirmwareMapper implements RowMapper<Firmware> {

    private static final FirmwareMapper FIRMWARE_MAPPER = new FirmwareMapper();

    private FirmwareMapper() {
    }

    public static FirmwareMapper getInstance() {
        return FIRMWARE_MAPPER;
    }

    @Override
    public Firmware mapRow(ResultSet rs, int i) throws SQLException {
        Firmware firmware = new Firmware();
        firmware.setData(rs.getString(Firmware.DATA));
        firmware.setName(rs.getString(Firmware.NAME));
        firmware.setDate_released(rs.getTimestamp(Firmware.DATE_RELEASED));
        return firmware;
    }

}

class RobotMapper implements RowMapper<Robot> {

    private static final RobotMapper ROBOT_MAPPER = new RobotMapper();

    private RobotMapper() {
    }

    public static RobotMapper getInstance() {
        return ROBOT_MAPPER;
    }

    @Override
    public Robot mapRow(ResultSet rs, int i) throws SQLException {
        Robot robot = new Robot();
        robot.setName(rs.getString(Robot.NAME));
        robot.setHardwareVersion(rs.getString(Robot.HARDWARE_VERSION));
        robot.setFirmwareName(rs.getString(Robot.FIRMWARE_NAME));
        return robot;
    }
}

class HistoryMapper implements RowMapper<History> {

    private static final HistoryMapper HISTORY_MAPPER = new HistoryMapper();

    private HistoryMapper() {
    }

    public static HistoryMapper getInstance() {
        return HISTORY_MAPPER;
    }

    @Override
    public History mapRow(ResultSet rs, int i) throws SQLException {
        History history = new History();
        history.setId(rs.getInt(History.ID));
        history.setRobot_name(rs.getString(History.ROBOT_NAME));
        history.setFirmware_name(rs.getString(History.FIRMWARE_NAME));
        history.setDate_associated(rs.getTimestamp(History.DATE_ASSOCIATED));
        return history;
    }
}