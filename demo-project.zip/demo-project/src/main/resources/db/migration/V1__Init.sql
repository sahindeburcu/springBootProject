
CREATE TABLE Robots (
	name VARCHAR PRIMARY KEY,
	hardware_version VARCHAR,
	firmware_name VARCHAR
);

CREATE SEQUENCE Seq_Firmwares;
CREATE TABLE Firmwares (
	name VARCHAR PRIMARY KEY,
	 -- For simplicity: Base64 encoded binary data
	 -- However never mind the data and its contents at all
	data VARCHAR,
	date_released TIMESTAMP
);

CREATE TABLE History (
    id INT PRIMARY KEY AUTO_INCREMENT,
    robot_name VARCHAR NOT NULL,
    firmware_name VARCHAR NOT NULL,
    date_associated TIMESTAMP NOT NULL
);

INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_1', 'hardware-model-abc','firmware_stock_A');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_2', 'hardware-model-abc','firmware_upgrade_A_1');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_3', 'hardware-model-abc','firmware_upgrade_A_1');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_4', 'hardware-model-def','firmware_stock_A');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_5', 'hardware-model-def','latest_firmwarename');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_6', 'hardware-model-def','firmware_stock_A');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_7', 'hardware-model-ghi','latest_firmwarename');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_8', 'hardware-model-ghi','firmware_stock_A');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_9', 'hardware-model-ghi','firmware_stock_A');
INSERT INTO Robots (name, hardware_version,firmware_name) VALUES ('robot_10', 'hardware-model-xyz','firmware_stock_A');

INSERT INTO Firmwares (name, data, date_released) VALUES ('firmware_stock_A', 'R29vZCB5b3Uga25vdyBob3cgdG8gZGVjb2RlIGJhc2UgNjQgOi0p','2021-01-17 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('update_firmware_stock_A', 'R22vdg843456725vdyBob3cgdG8gZGVjb2RlIGJhc2UgNjQgOi0p','2020-09-15 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('firmware_upgrade_A_1', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2020-11-01 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('firmware_upgrade_A_2', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2021-01-05 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('new_firmware_upgrade_A_2', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2020-10-25 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('testfirmwarename', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2020-06-23 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('latest_firmwarename', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2020-07-12 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('old_firmware', 'R29vZCB5b3Uga25vdyBob3cgdG8gZGVjb2RlIGJhc2UgNjQgOi0p','2020-12-20 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('update_firmware_stock_2', 'R29vZCB5b3Uga25vdyBob3cgdG8gZGVjb2RlIGJhc2UgNjQgOi0p','2020-12-20 00:00:00');


INSERT INTO History (id,robot_name,firmware_name,date_associated) VALUES ('1','robot_1','firmware_stock_A','2021-01-22 00:00:00.00');
INSERT INTO History (id,robot_name,firmware_name,date_associated) VALUES ('2','robot_2','firmware_upgrade_A_1','2020-12-25 00:00:00.00');