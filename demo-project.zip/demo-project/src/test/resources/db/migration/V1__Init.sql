
CREATE TABLE Robots (
	name VARCHAR PRIMARY KEY,
	hardware_version VARCHAR,
	firmware_name VARCHAR
);

CREATE SEQUENCE Seq_Firmwares;
CREATE TABLE Firmwares (
	name VARCHAR PRIMARY KEY,
	 -- For simplicity: Base64 encoded binary data
	 -- However never mind the data and its contents at all
	data VARCHAR,
	date_released TIMESTAMP
);

CREATE TABLE History (
    id INT PRIMARY KEY AUTO_INCREMENT,
    robot_name VARCHAR,
    firmware_name VARCHAR,
    date_associated TIMESTAMP
);

INSERT INTO Robots (name, hardware_version, firmware_name) VALUES ('robot_1', 'hardware-model-abc','firmware_stock_A');
INSERT INTO Robots (name, hardware_version, firmware_name) VALUES ('robot_2', 'hardware-model-abc','firmware_upgrade_A_2');
INSERT INTO Robots (name, hardware_version, firmware_name) VALUES ('robot_3', 'hardware-model-abc','firmware_upgrade_A_2');
INSERT INTO Robots (name, hardware_version, firmware_name) VALUES ('testrobotname', 'hardware-model-xyz','firmware_upgrade_A_2');

INSERT INTO Firmwares (name, data, date_released) VALUES ('firmware_stock_A', 'R29vZCB5b3Uga25vdyBob3cgdG8gZGVjb2RlIGJhc2UgNjQgOi0p','2021-01-17 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('update_firmware_stock_A', 'R22vdg843456725vdyBob3cgdG8gZGVjb2RlIGJhc2UgNjQgOi0p','2020-09-15 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('firmware_upgrade_A_1', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2020-11-01 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('firmware_upgrade_A_2', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2021-01-05 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('updated_firmware_upgrade_B_2', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2021-01-05 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('new_firmware_upgrade_A_2', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2020-10-25 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('testfirmwarename', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2020-06-23 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('latest_firmwarename', 'WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu','2021-05-30 00:00:00.00');
INSERT INTO Firmwares (name, data, date_released) VALUES ('old_firmware', 'R29vZCB5b3Uga25vdyBob3cgdG8gZGVjb2RlIGJhc2UgNjQgOi0p','2020-12-20 00:00:00.00');


INSERT INTO History (id,robot_name,firmware_name,date_associated) VALUES ('1','robot_1','firmware_upgrade_A_1','2021-01-22 00:00:00.00');