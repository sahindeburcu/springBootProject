package tr.demoproject;

import tr.demoproject.persistent.Firmware;
import tr.demoproject.persistent.Robot;
import tr.demoproject.repository.DemoprojectRepository;
import tr.demoproject.repository.exceptions.InvalidRequestException;
import org.junit.jupiter.api.Test;

import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class DemoApplicationTests {

    @Test
    void contextLoads() {

    }

    @Autowired
    DemoprojectRepository demoprojectRepository;

    @Test
    void test_uploadNewFirmwareForFirmwareNameWithInvalidCharacter() {

        Firmware mockedFirmware = Mockito.mock(Firmware.class);
        when(mockedFirmware.getName()).thenReturn("Testname+");
        when(mockedFirmware.getData()).thenReturn("testdata");
        assertThrows(InvalidRequestException.class, () -> demoprojectRepository.uploadNewFirmware(mockedFirmware)) ;

    }

    @Test
    void test_uploadNewFirmwareForEmptyFirmwareNameOrNullFirmware() {
        Firmware mockedFirmware = Mockito.mock(Firmware.class);
        when(mockedFirmware.getName()).thenReturn("");
        when(mockedFirmware.getData()).thenReturn("testdata");
        assertThrows(InvalidRequestException.class, () -> demoprojectRepository.uploadNewFirmware(mockedFirmware)) ;

        Firmware nullFirmware = null;
        when(mockedFirmware.getName()).thenReturn("testname");
        when(mockedFirmware.getData()).thenReturn("testdata");
        assertThrows(InvalidRequestException.class, () -> demoprojectRepository.uploadNewFirmware(nullFirmware)) ;
    }

    @Test
    void test_uploadNewFirmwareShouldWorkWithValidInputs() {
        Firmware mockedFirmware = Mockito.mock(Firmware.class);
        when(mockedFirmware.getName()).thenReturn("testname");
        when(mockedFirmware.getData()).thenReturn("testdata");
        when(mockedFirmware.getDate_released()).thenReturn(Timestamp.valueOf("2021-01-01 00:00:00"));

        final boolean insertValue = demoprojectRepository.uploadNewFirmware(mockedFirmware);
        assertTrue(insertValue);
    }

    @Test
    void test_deleteFirmwareSuccessCase() {
        final String invalid_name = "firmware_upgrade_A_2";
        final boolean result = demoprojectRepository.deleteFirmware(invalid_name);
        assertTrue(result);
    }

    @Test
    void test_deleteFirmwareShouldThrowException() {
        final String invalid_name = "invalidname-+%";
        assertThrows(InvalidRequestException.class, () -> demoprojectRepository.deleteFirmware(invalid_name)) ;
    }

    @Test
    void test_deleteFirmwareShouldNotThrowException() {
        final String invalid_name = "valid_name";
        assertDoesNotThrow(() -> demoprojectRepository.deleteFirmware(invalid_name)) ;
    }

    @Test
    void test_updateFirmwareForJustData() {

        final String firmware_name = "updated_firmware_upgrade_B_2";
        final String newfirmware_name = "";
        final String expected_data = "WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu";

        assertTrue(demoprojectRepository.updateFirmware(firmware_name,newfirmware_name,expected_data));

        Firmware firmware = demoprojectRepository.findFirmwareAndValidate(firmware_name);
        assertEquals(expected_data, firmware.getData());
        assertEquals(firmware_name, firmware.getName());
    }

    @Test
    void test_updateFirmwareForJustFirmware() {

        final String firmware_name = "update_firmware_stock_A";
        final String newfirmware_name = "new_update_firmware_stock_A";
        final String data = "";

        assertTrue(demoprojectRepository.updateFirmware(firmware_name,newfirmware_name,data));

        Firmware firmware = demoprojectRepository.findFirmwareAndValidate(newfirmware_name);
        assertEquals(newfirmware_name, firmware.getName());
    }

    @Test
    void test_updateFirmwareForFirmwareAndData() {

        final String firmware_name = "old_firmware";
        final String newfirmware_name = "new_firmware";
        final String expected_data = "WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu";

        assertTrue(demoprojectRepository.updateFirmware(firmware_name,newfirmware_name,expected_data));

        Firmware firmware = demoprojectRepository.findFirmwareAndValidate(newfirmware_name);
        assertEquals(newfirmware_name, firmware.getName());
        assertEquals(expected_data, firmware.getData());
    }

    @Test
    void test_updateFirmwareForEmptyFirmwareName(){
        final String firmware_name = "";
        final String newfirmware_name = "new_firmware";
        final String data = "WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu";

        assertThrows(InvalidRequestException.class,() ->demoprojectRepository.updateFirmware(firmware_name,newfirmware_name,data));
    }
    @Test
    void test_updateFirmwareForInvalidFirmwareName(){
        final String firmware_name = "test_firmwarename+";
        final String newfirmware_name = "new_firmware";
        final String data = "WWV0IGFnYWluIGEgYmFzZSA2NCBlbmNvZGVkIHRleHQu";

        assertThrows(InvalidRequestException.class,() ->demoprojectRepository.updateFirmware(firmware_name,newfirmware_name,data));
    }
    @Test
    void test_updateFirmwareForEmptyNewFirmwareNameAndData(){
        final String firmware_name = "testfirmwarename";
        final String newfirmware_name = "";
        final String data = "";

        assertThrows(InvalidRequestException.class,() ->demoprojectRepository.updateFirmware(firmware_name,newfirmware_name,data));
    }
    @Test
    void test_updateRobotFirmwareForEmptyRobotName(){
        final String robot_name = "";
        final String firmware_name = "new_firmware_upgrade_A_2";
        assertThrows(InvalidRequestException.class,() ->demoprojectRepository.updateRobotFirmware(robot_name,firmware_name));
    }

    @Test
    void test_updateRobotFirmwareSuccessCase(){
        final String robot_name = "testrobotname";
        final String firmware_name = "testfirmwarename";
        assertTrue(demoprojectRepository.updateRobotFirmware(robot_name,firmware_name));
    }

    @Test
    void test_associateRobotsWithFirmwareSuccessCase(){
        Robot mockedRobot = Mockito.mock(Robot.class);
        when(mockedRobot.getName()).thenReturn("robot_1");

        Robot mockedRobot2 = Mockito.mock(Robot.class);
        when(mockedRobot2.getName()).thenReturn("robot_2");

        List<Robot> robotList = new ArrayList<>();
        robotList.add(mockedRobot);
        robotList.add(mockedRobot2);

        final String firmware_name = "testfirmwarename";

        List<Boolean> result = new ArrayList<Boolean>();
        result.add(true);
        result.add(true);

        assertEquals(demoprojectRepository.associateRobotsWithFirmware(robotList,firmware_name), result);
    }

    @Test
    void test_associateRobotsWithFirmwareForNonExistentRobot(){
        Robot mockedRobot = Mockito.mock(Robot.class);
        when(mockedRobot.getName()).thenReturn("robot_nonexistent");

        Robot mockedRobot2 = Mockito.mock(Robot.class);
        when(mockedRobot2.getName()).thenReturn("robot_2");

        List<Robot> robotList = new ArrayList<>();
        robotList.add(mockedRobot);
        robotList.add(mockedRobot2);

        final String firmware_name = "testfirmwarename";

        List<Boolean> result = new ArrayList<Boolean>();
        result.add(false);
        result.add(true);

        assertEquals(demoprojectRepository.associateRobotsWithFirmware(robotList,firmware_name), result);
    }

    @Test
    void test_findRobotAndValidateForEmptyRobotName(){
        final String invalid_robot_name = "";
        assertThrows(InvalidRequestException.class, () -> demoprojectRepository.findRobotAndValidate(invalid_robot_name)) ;
    }

    @Test
    void test_findRobotAndValidateSuccessCase(){
        final String robot_name = "robot_1";

        Robot expected_robot = new Robot();
        expected_robot.setName(robot_name);

        Robot result_robot = demoprojectRepository.findRobotAndValidate(robot_name);
        assertEquals(expected_robot,result_robot);
    }

    @Test
    void test_findFirmwareAndValidateSuccessCase(){
        final String firmware_name = "testfirmwarename";

        Firmware expected_robot = new Firmware();
        expected_robot.setName(firmware_name);

        Firmware result_robot = demoprojectRepository.findFirmwareAndValidate(firmware_name);
        assertEquals(expected_robot,result_robot);
    }

    @Test
    void test_addRelationtToHistorySuccessCase(){
        final String firmware_name = "new_testfirmwarename";
        final String robot_name = "new_testrobotname";
        assertTrue(demoprojectRepository.addRelationtToHistory(robot_name,firmware_name));
    }

    @Test
    void test_downloadTheLatestFirmwareSuccessCase(){
        final String latest_firmware_name = "latest_firmwarename";
        final String robot_name = "robot_1";

        assertTrue(demoprojectRepository.downloadTheLatestFirmware(robot_name));

        Robot robot=  demoprojectRepository.findRobotAndValidate(robot_name);
        assertEquals(robot.getFirmwareName(),latest_firmware_name);
    }

    @Test
    void test_downloadTheLatestFirmwareEmptyRobotName(){
        final String invalid_robot_name = "";
        assertThrows(InvalidRequestException.class, () -> demoprojectRepository.downloadTheLatestFirmware(invalid_robot_name)) ;
    }




}
